package de.vogella.jfreechart.swing.pie;

import de.vogella.jfreechart.swing.pie.mainFrame;

public class GoGreen {

    public static void main(String [] args){
        mainFrame mf= new mainFrame();
        mf.setVisible(true);
    }


}
