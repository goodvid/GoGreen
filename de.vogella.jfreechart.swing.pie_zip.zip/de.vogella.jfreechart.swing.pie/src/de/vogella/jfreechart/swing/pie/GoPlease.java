package de.vogella.jfreechart.swing.pie;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;

import javax.swing.*;
import java.awt.*;

public class GoPlease extends JFrame {
    //JTextField j = new JTextField();


    private JButton button1 = new JButton("bb");
    private JTextField textField1 = new JTextField();
    private JButton button2 = new JButton("ggg");
    private JFrame frame = new JFrame();

    public GoPlease() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 102, 51));
        panel.setBounds(50, 64, 955, 888);
        frame.getContentPane().add(panel);




        panel.add(button1);
        panel.add(textField1);
        panel.add(button2);




    }


}
