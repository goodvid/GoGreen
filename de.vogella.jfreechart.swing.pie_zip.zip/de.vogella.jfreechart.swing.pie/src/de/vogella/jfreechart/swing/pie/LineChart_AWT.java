package de.vogella.jfreechart.swing.pie;

import jdk.jfr.Category;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.title.LegendTitle;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LineChart_AWT extends ApplicationFrame implements ActionListener {

    public  LineChart_AWT( DefaultCategoryDataset dataset) {
        super("Energy Usage Per Month");

        // super(applicationTitle);
        JFreeChart lineChart = ChartFactory.createLineChart(
                "Resourse Usage Per Month",
                "Month", "Watt khw",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);




        ChartPanel chartPanel = new ChartPanel( lineChart);
        chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
        setContentPane( chartPanel );

        Font f = new Font(Font.SANS_SERIF,Font.ITALIC,10);
        LegendTitle legend = lineChart.getLegend();
        legend.setItemFont(f);

        /*final JPanel content = new JPanel(new BorderLayout());
         chartPanel = new ChartPanel(lineChart);
        content.add(chartPanel);*/



        //content.add(button1);

        //setContentPane(content);





    }




    private DefaultCategoryDataset createDataset( ) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
        dataset.addValue( 15 , "schools" , "1970" );
        dataset.addValue( 30 , "schools" , "1980" );
        dataset.addValue( 60 , "schools" ,  "1990" );
        dataset.addValue( 120 , "schools" , "2000" );
        dataset.addValue( 240 , "schools" , "2010" );
        dataset.addValue( 300 , "schools" , "2014" );

        dataset.addValue( 10 , "bike" , "1970" );
        dataset.addValue( 20 , "bike" , "1980" );
        dataset.addValue( 30 , "bike" ,  "1990" );
        dataset.addValue( 40 , "bike" , "2000" );
        dataset.addValue( 50 , "bike" , "2010" );
        dataset.addValue( 300 , "bike" , "2014" );
        return dataset;
    }

    public static void main( String[ ] args ) {
        DefaultCategoryDataset d = new DefaultCategoryDataset();
        LineChart_AWT chart = new LineChart_AWT(d);

        // jPanel2.add();
        chart.pack();
        RefineryUtilities.centerFrameOnScreen( chart );
        chart.setVisible( true );


    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
