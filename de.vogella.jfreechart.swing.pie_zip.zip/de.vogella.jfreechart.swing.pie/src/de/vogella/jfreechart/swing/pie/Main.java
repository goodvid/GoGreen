package de.vogella.jfreechart.swing.pie;

import org.jfree.ui.RefineryUtilities;

public class Main {
    public static void main(String[] args) {
        mainFrame mf = new mainFrame();
        mf.setVisible(true);

    }
}
