package de.vogella.jfreechart.swing.pie;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;



public class PieChart extends ApplicationFrame {
    private static int sumElectricity;
    private static int sumWater;

    public PieChart(String title, int sumElectricity,int sumWater) {
        super( title );
        this.sumElectricity = sumElectricity;
        this.sumWater = sumWater;
        setContentPane(createDemoPanel( ));

    }

    private static PieDataset createDataset() {
        DefaultPieDataset dataset = new DefaultPieDataset( );

        dataset.setValue( "Electricity" , new Integer( sumElectricity ) );
        dataset.setValue( "Water" , new Double( sumWater ) );

        return dataset;
    }

    private static JFreeChart createChart( PieDataset dataset ) {
        JFreeChart chart = ChartFactory.createPieChart(
                "Costs",   // chart title
                dataset,          // data
                true,             // include legend
                true,
                false);

        return chart;
    }

    public static JPanel createDemoPanel( ) {
        JFreeChart chart = createChart(createDataset( ) );
        return new ChartPanel( chart );
    }

    public static void main( String[ ] args ) {
        PieChart demo = new PieChart( "Costs", 100, 200);
        demo.setSize( 560 , 367 );
        RefineryUtilities.centerFrameOnScreen( demo );
        demo.setVisible( true );
    }
}