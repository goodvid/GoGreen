
package de.vogella.jfreechart.swing.pie;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.RefineryUtilities;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

public class mainFrame extends JFrame {

    private JTabbedPane tabbedPane1 ;
    private JPanel rootPanel;
    private JTable table1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton submitDataButton;
    private JTextField textField4;
    private JTextField textField5;
    private JButton button1;
    private JPanel jPanel2;
    private JTextField textField6;
    private JTextField textField7;
    private JButton button2;
    private JButton graphOfWaterConsumptionButton;

    private int waterSum;
    private int energySum;


    public mainFrame() {

        add(rootPanel);
        setTitle("GoGreen");
        setSize(800,600);
        createTableHeadings();
        //jPanel2.add()
        submitDataButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {





                String date = textField1.getText();
                String waterUsage = textField2.getText();
                String energyUsage = textField3.getText();
                String waterGoal = textField4.getText();
                String energyGoal = textField5.getText();
                String waterCost = textField6.getText();
                String energyCost = textField7.getText();



                String wgMet = "";
                String egMet = "";
                if (waterGoal.equals("") || energyGoal.equals(""))
                {
                    JOptionPane.showMessageDialog(null,
                        "You must submit goal data before inputting energy and water usage data!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    //System.out.println("ghjkl");
                }

                int wu = Integer.parseInt(waterUsage);
                int eu = Integer.parseInt(energyUsage);
                int wg = Integer.parseInt(waterGoal);
                int eg = Integer.parseInt(energyGoal);
                double wc = wu/Integer.parseInt(waterCost);
                double ec = eu/Integer.parseInt(energyCost);




                String[] waterList = {"Take shorter showers.", "Replace your showerhead.", "Fix leaky faucets.", "Fix leaky ductwork.", "Install Water-Efficient Toilets", "Water your lawn at the right time"};
                Random r = new Random();
                String[] energyList = {"Check seals on windows, doors and appliances.", "Give your thermostat a nudge.", "Adjust your fridge and freezer temperature.", "Don’t wash clothes in hot water.", "Purchase energy-efficient appliances.", "Swap out your lightbulbs."};
                Random r2 = new Random();

                String message = "";

               // Random r2 = new Random();
                if (wu > wg){
                    wgMet = "No";
                    message = waterList[r.nextInt(waterList.length)];
                    JOptionPane.showMessageDialog(null, message, "Water Saving Tip:", JOptionPane.INFORMATION_MESSAGE);
                } else{
                    wgMet = "Yes";
                }
                if (eu > eg){
                    egMet = "No";
                    message = energyList[r.nextInt(energyList.length)];
                    JOptionPane.showMessageDialog(null, message, "Energy Saving Tip", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    egMet = "Yes";
                }

                DefaultTableModel model = (DefaultTableModel)table1.getModel();
                Object [] row = new Object[5];
                row[0] = date;
                row[1] = waterUsage;
                row[2] = energyUsage;
                row[3] = wgMet;
                row[4] = egMet;
                model.addRow(row);


            }
        });

        tabbedPane1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);


            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createDataSet();


                LineChart_AWT chart = new LineChart_AWT(createDataSet());


               // jPanel2.add();
                chart.pack();
                RefineryUtilities.centerFrameOnScreen( chart );
                chart.setVisible( true );
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] sumValues = returnSumValues();
                System.out.println(sumValues[0]);
                System.out.println(sumValues[1]);

                PieChart demo = new PieChart("Cost", sumValues[1], sumValues[0]);
                demo.setSize( 560 , 367 );
                RefineryUtilities.centerFrameOnScreen( demo );
                demo.setVisible( true );
            }
        });
        graphOfWaterConsumptionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createDataSet2();


                LineChart_AWT chart = new LineChart_AWT(createDataSet2());


                // jPanel2.add();
                chart.pack();
                RefineryUtilities.centerFrameOnScreen( chart );
                chart.setVisible( true );

            }
        });
    }
    public int[] returnSumValues() {
        int sumVaules[] = new int[2];
        sumVaules[0] = 0;
        sumVaules[1] = 0;

        for (int i = 0; i < table1.getRowCount(); i++) {
            sumVaules[0] +=  Integer.parseInt((String)table1.getValueAt(i,1)) ;
            sumVaules[1] += Integer.parseInt((String)table1.getValueAt(i,2));
        }
        sumVaules[0] *= Integer.parseInt(textField6.getText());
        sumVaules[1] *= Integer.parseInt(textField7.getText());

        return sumVaules;

    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }

    public void createTableHeadings(){
        DefaultTableModel dtm = (DefaultTableModel) table1.getModel();
        dtm.addColumn("Date ");
        dtm.addColumn("Water Usage");
        dtm.addColumn("Energy Usage");
        dtm.addColumn("Met Water Goal");
        dtm.addColumn("Met Energy Goal");
    }





    public DefaultCategoryDataset createDataSet() {
        ArrayList<Point> point = new ArrayList<Point>();
        //System.out.println("hh");

        int x = 0;

        for (int i = 0; i < table1.getRowCount(); i++) {

                 x = Integer.parseInt((String)table1.getValueAt(i,0));
                int y = Integer.parseInt((String)table1.getValueAt(i,2));
                Point p = new Point(x,y);
                point.add(p);




        }




        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (int i = 0; i < point.size(); i++) {
            dataset.addValue((point.get(i).getY()),"Electricity Usage",Double.toString(point.get(i).getX()));

            dataset.addValue(Integer.parseInt(textField5.getText()),"Electricity Goal",Double.toString(point.get(i).getX()));
        }


        return  dataset;
    }

    public DefaultCategoryDataset createDataSet2() {
        ArrayList<Point> point2 = new ArrayList<Point>();
        //System.out.println("hh");

        int x = 0;

        for (int i = 0; i < table1.getRowCount(); i++) {

            x = Integer.parseInt((String)table1.getValueAt(i,0));
            int y = Integer.parseInt((String)table1.getValueAt(i,1));
            Point p = new Point(x,y);
            point2.add(p);




        }




        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (int i = 0; i < point2.size(); i++) {
            dataset.addValue((point2.get(i).getY()),"Water Usage",Double.toString(point2.get(i).getX()));

            dataset.addValue(Integer.parseInt(textField4.getText()),"Water Goal",Double.toString(point2.get(i).getX()));
        }


        return  dataset;
    }



    public static void main(String[] args) {
        mainFrame mf = new mainFrame();
        mf.setVisible(true);
        //System.out.println("kggj");

    }





}


